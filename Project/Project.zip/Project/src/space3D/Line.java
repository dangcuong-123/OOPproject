package space3D;

public class Line {

}
