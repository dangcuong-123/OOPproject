package space3D;

import java.util.ArrayList;
import java.util.List;

public class Camera {
	public Point camPosition;
	public double angleHeight;	// Goc cao
	public double angleWidth;	// Goc rong
	public Plane3D inPlane; // mat phang camera nam tren
	
	public Camera(Point camPosition, double angleHeight, double angleWidth) {
		super();
		this.camPosition = camPosition;
		this.angleHeight = angleHeight;
		this.angleWidth = angleWidth;
	}
	
	// Lay wall ma cam nam tren day
	public int getWallCamInIt(Rectangular room) {
		for (int i=1;i<5;i++) {
			if (Calculate3D.distancePointPlane(this.getCamPosition(), room.getPlanes().get(i)) <= 1e-5)
				return i;
		}
		return -1; // Khong nam tren tuong
	}
	
	// Lay 4 dinh cua vung nhin thay
	public List<Point> getListPointInBottom(Rectangular room) {
		List<Point> ListPointInBottom = new ArrayList<Point>();
		int wallCamInIt = getWallCamInIt(room);
		// Tinh chieu cao chop tu giac
		double heightCam;
		if (wallCamInIt == 1 || wallCamInIt == 3)
			heightCam = Calculate3D.distanceTwoPlane(room.getPlanes().get(1), room.getPlanes().get(3));
		else
			heightCam = Calculate3D.distanceTwoPlane(room.getPlanes().get(2), room.getPlanes().get(4));
		
		// Tim hinh chieu camera den mat doi dien
		Point  ProjectionpoinOfCam = new Point();
		if (wallCamInIt == 1)
			ProjectionpoinOfCam = new Calculate3D.ProjectionPointToPlane(this.getCamPosition(), room.getPlanes().get(3));
		
		return ListPointInBottom;
	}
	
	// Check 1 diem co thuoc vung nhin thay cua camera ko
	public boolean checkPointInVisibleAreaOfCam(Rectangular room, Point position) {
		
		return true;
	}
	
	public Point getCamPosition() {
		return camPosition;
	}

	public void setCamPosition(Point camPosition) {
		this.camPosition = camPosition;
	}

	public double getAngleHeight() {
		return angleHeight;
	}
	
	public void setAngleHeight(double angleHeight) {
		this.angleHeight = angleHeight;
	}
	
	public double getAngleWidth() {
		return angleWidth;
	}
	
	public void setAngleWidth(double angleWidth) {
		this.angleWidth = angleWidth;
	}
	
	public Plane3D getInPlane() {
		return inPlane;
	}

	public void setInPlane(Plane3D upperPlane) {
		this.inPlane = upperPlane;
	}
}
