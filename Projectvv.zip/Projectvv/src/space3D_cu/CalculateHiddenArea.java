package space3D;

public class CalculateHiddenArea {
	public Room myRoom;
	//public int[][][] roomMatrix3D;
	public int wideRoom;
	public int longRoom;
	public int highRoom;
	//height
	
	public CalculateHiddenArea(Room myRoom) {
		// TODO Auto-generated constructor stub
		this.myRoom = myRoom;
		this.wideRoom = (int) (myRoom.getRoom().getcornerOfRec().get(6).getX());
		this.longRoom = (int) (myRoom.getRoom().getcornerOfRec().get(6).getY());
		this.highRoom = (int) (myRoom.getRoom().getcornerOfRec().get(1).getZ());
		//roomMatrix3D = new int[this.wideRoom + 10][this.longRoom + 10][this.highRoom + 10];

		System.out.println(this.wideRoom);
		System.out.println(this.longRoom);
		System.out.println(this.highRoom);
	}
	
	// neu ko thay thi tra ve true
	public boolean pointIsHidden(Point position) {
		for(Camera cam : myRoom.getCamInRoom()) {
			
			// check = 1 la vat khong nhin thay
			int check = 0;
			for(Rectangular object : myRoom.getRecInRoom()) {
				if (Calculate3D.checkIntersectPointInRec(cam.getCamPosition(), position, new Line3D(cam.getCamPosition(), position), object))
					check = 1;
				if(check == 1) {
					break;
				}
			}
			if(check == 0) {
				return false;
			}
		}
		return true;
	}
	
	public double calculateHidden() {
		int count = 0;
		for(int i=0;i<this.wideRoom;i++) {
			for(int j=0; j<this.longRoom; j++) {
				for(int k=0; k<this.highRoom;k++) {
					if(pointIsHidden(new Point(i,j,k))) {
						count += 1;
					}
				}
			}
		}
		return 100 * (1 - (float) (count)/(this.wideRoom*this.longRoom*this.highRoom));
	}
}
