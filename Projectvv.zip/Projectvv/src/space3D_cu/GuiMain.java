package space3D;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.border.TitledBorder;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;



public class GuiMain extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	JButton btnReadFile, btnCheckPoint, btnCaculate, 
	btnViewTheHidden, btnSetMinCam, btnPositionCam;
	//private JTextField textField;

	/**
	 * Create the frame.
	 */
	public GuiMain() {
		//Create Button
		btnReadFile 	 = new JButton("Read File");
		btnCheckPoint 	 = new JButton("Check a point ");
		btnCaculate 	 = new JButton("Caculate The Hidden Area");
		btnViewTheHidden = new JButton("Display The Hidden Area");
		btnSetMinCam 	 = new JButton("Set minimum the number of camera");
		btnPositionCam	 = new JButton("Determine Camera Position ");
		
		//Create contentPane
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		getContentPane().setBackground(Color.WHITE);
		contentPane.setLayout(null);
		
		//mainframe
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(100, 100, 550, 450);
		this.setTitle("CAMERA APP");
		this.setLocationRelativeTo(null);
		
		//Create Panel
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBorder(new TitledBorder(null, "Please choose a function", 
				TitledBorder.CENTER, TitledBorder.TOP, null, null));
		panel.setBounds(103, 11, 333, 368);
		contentPane.add(panel);
		panel.setLayout(null);
		
		//Read File
		btnReadFile.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnReadFile.setBounds(22, 41, 286, 39);
		panel.add(btnReadFile);
		btnReadFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame f1 = new JFrame("READ FILE");
				f1.setVisible(true);
				f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				f1.setBounds(100, 100, 550, 450);
				f1.getContentPane().setLayout(null);
				f1.setLocationRelativeTo(null);
				
				JButton btnCheck = new JButton("Check");
				btnCheck.setBounds(308, 83, 89, 23);
				f1.getContentPane().add(btnCheck);
				
				JButton btnClear = new JButton("Clear");
				btnClear.setBounds(379, 368, 89, 23);
				f1.getContentPane().add(btnClear);
				
				JTextArea textArea = new JTextArea();
				textArea.setBounds(40, 142, 449, 209);
				f1.getContentPane().add(textArea);
				textArea.addMouseListener(new MouseAdapter() {
					//click chuột vào thì nó biến mất, nhược điểm là không sửa được
					@Override
					public void mouseClicked(MouseEvent e) {
						textArea.setText("");
					}
				});
				
				JLabel lblResult = new JLabel("Result after reading");
				lblResult.setHorizontalAlignment(SwingConstants.CENTER);
				lblResult.setBounds(30, 107, 166, 23);
				f1.getContentPane().add(lblResult);
				
				JTextField textField = new JTextField();
				textField.setBounds(228, 37, 247, 32);
				f1.getContentPane().add(textField);
				textField.setColumns(10);
				
				
				JScrollBar scrollBar = new JScrollBar();
				scrollBar.setBounds(513, 142, 17, 234);
				f1.getContentPane().add(scrollBar);
				
				JLabel lblNewLabel = new JLabel("Enter the path of file input");
				lblNewLabel.setBounds(42, 46, 154, 14);
				f1.getContentPane().add(lblNewLabel);
				//new CheckFile();
				btnCheck.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						String url = "";
				       url = textField.getText();

				InputFile test = new InputFile(url);
				test.GetInput();
					}
				});
				
			}
	});


		btnCaculate.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnCaculate.setBounds(22, 141, 286, 39);
		panel.add(btnCaculate);
		btnCaculate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame f3 = new JFrame("CHECK A POINT");
				f3.setVisible(true);
				f3.setBounds(100, 100, 550, 450);
				f3.getContentPane().setLayout(null);
				f3.setLocationRelativeTo(null);


			}
		});


		btnViewTheHidden.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnViewTheHidden.setBounds(22, 195, 286, 39);
		panel.add(btnViewTheHidden);
		btnViewTheHidden.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JFrame f4 = new JFrame("CHECK A POINT");
				f4.setVisible(true);
				f4.setBounds(100, 100, 550, 450);
				f4.getContentPane().setLayout(null);
				f4.setLocationRelativeTo(null);
				
			}
		});

		btnSetMinCam.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnSetMinCam.setBounds(22, 245, 286, 39);
		panel.add(btnSetMinCam);
		btnSetMinCam.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JFrame f5 = new JFrame("CHECK A POINT");
				f5.setVisible(true);
				f5.setBounds(100, 100, 550, 450);
				f5.getContentPane().setLayout(null);
				f5.setLocationRelativeTo(null);
				
			}
		});

		btnPositionCam.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnPositionCam.setBounds(22, 295, 286, 39);
		panel.add(btnPositionCam);
		btnPositionCam.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JFrame f6 = new JFrame("CHECK A POINT");
				f6.setVisible(true);
				f6.setBounds(100, 100, 550, 450);
				f6.getContentPane().setLayout(null);
				f6.setLocationRelativeTo(null);
				
			}
		});


		btnCheckPoint.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnCheckPoint.setBounds(22, 91, 286, 39);
		panel.add(btnCheckPoint);
		btnCheckPoint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame f2 = new JFrame("CHECK A POINT");
				f2.setVisible(true);
				f2.setBounds(100, 100, 550, 450);
				f2.getContentPane().setLayout(null);
				f2.setLocationRelativeTo(null);

				JLabel lblX = new JLabel("X");
				lblX.setFont(new Font("Tahoma", Font.BOLD, 11));
				lblX.setBounds(35, 127, 16, 14);
				f2.getContentPane().add(lblX);

				JLabel lblY = new JLabel("Y");
				lblY.setFont(new Font("Tahoma", Font.BOLD, 11));
				lblY.setBounds(185, 127, 16, 14);
				f2.getContentPane().add(lblY);

				JLabel lblZ= new JLabel("Z");
				lblZ.setFont(new Font("Tahoma", Font.BOLD, 11));
				lblZ.setBounds(335, 127, 16, 14);
				f2.getContentPane().add(lblZ);

				JTextField textField= new JTextField();
				textField.setBounds(50, 124, 112, 28);
				f2.getContentPane().add(textField);
				textField.setColumns(10);
				textField.addMouseListener(new MouseAdapter() {
					//click chuột vào thì nó biến mất, nhược điểm là không sửa được
					@Override
					public void mouseClicked(MouseEvent e) {
						textField.setText("");
					}
				});

				JTextField textField_1 = new JTextField();
				textField_1.setBounds(200, 124, 112, 28);
				f2.getContentPane().add(textField_1);
				//textField_1.setColumns(10);
				textField_1.addMouseListener(new MouseAdapter() {
					//click chuột vào thì nó biến mất, nhược điểm là không sửa được
					@Override
					public void mouseClicked(MouseEvent e) {
						textField_1.setText("");
					}
				});

				JTextField textField_2 = new JTextField();
				textField_2.setBounds(350, 124, 112, 28);
				f2.getContentPane().add(textField_2);
				//textField_2.setColumns(10);
				textField_2.addMouseListener(new MouseAdapter() {
					//click chuột vào thì nó biến mất, nhược điểm là không sửa được
					@Override
					public void mouseClicked(MouseEvent e) {
						textField_2.setText("");
					}
				});

				JButton btnCl = new JButton("Clear ");
				btnCl.setFont(new Font("Tahoma", Font.BOLD, 11));
				btnCl.setBounds(390, 191, 72, 28);
				f2.getContentPane().add(btnCl);

				JTextArea textArea = new JTextArea();
				btnCl.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						textArea.setText("");
					}
				});

				JButton btnCheck = new JButton("Check");
				btnCheck.setFont(new Font("Tahoma", Font.BOLD, 11));
				btnCheck.setBounds(295, 191, 72, 28);
				f2.getContentPane().add(btnCheck);
				btnCheck.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub

					}
				});

				//JTextArea textArea = new JTextArea();
				textArea.setBounds(74, 253, 387, 85);
				f2.getContentPane().add(textArea);

				JLabel lbl1 = new JLabel("");
				lbl1.setBounds(57, 62, 72, 28);
				f2.getContentPane().add(lbl1);

				JLabel lblMess = new JLabel("Enter the coordinate point you want to check below: ");
				lblMess.setFont(new Font("Tahoma", Font.PLAIN, 14));
				lblMess.setBounds(87, 62, 419, 28);
				f2.getContentPane().add(lblMess);
				f2.setVisible(true);
				f2.setBounds(100, 100, 550, 450);
				f2.setLocationRelativeTo(null);




			}
		});


	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {

				GuiMain frame = new GuiMain();
				frame.setVisible(true);
			}
		});
	}
}

