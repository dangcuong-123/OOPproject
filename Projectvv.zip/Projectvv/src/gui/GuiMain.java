package gui;


import java.awt.Color;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import space3D.*;
import javax.swing.SwingConstants;
import javax.swing.UIManager;



public class GuiMain extends JFrame {

	private static final long serialVersionUID = 1L;
	private  Room rm ;
	public static String mess = "";
	public static JTextArea textArea = new JTextArea();
	private JPanel contentPane;
	JButton btnReadFile, btnCheckPoint, btnCaculate, 
	btnViewTheHidden, btnSetMinCam, btnPositionCam;

	public GuiMain() {
		init();

	}
	public void init() {
		//Create Button
		btnReadFile 	 = new JButton("Read File");
		btnCheckPoint 	 = new JButton("Check a point ");
		btnCaculate 	 = new JButton("Caculate The Hidden Area");
		btnViewTheHidden = new JButton("Display The Hidden Area");
		btnSetMinCam 	 = new JButton("Set minimum the number of camera");
		btnPositionCam	 = new JButton("Determine Camera Position ");

		//Create contentPane
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		getContentPane().setBackground(UIManager.getColor("TextArea.inactiveForeground"));
		contentPane.setLayout(null);

		//mainframe
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(100, 100, 700, 600);
		this.setTitle("CAMERA APP");
		this.setLocationRelativeTo(null);

		//Read File
		btnReadFile.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnReadFile.setBounds(22, 48, 286, 39);
		getContentPane().add(btnReadFile);
		btnReadFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Create a file chooser
				final JFileChooser fc = new JFileChooser("C:\\Users\\Dell 7490\\eclipse-workspace\\Projectvv\\src\\");

				//In response to a button click:
				fc.showOpenDialog(fc);
				//System.out.println(fc.getSelectedFile());
				InputFile file = new InputFile(fc.getSelectedFile().toString());
				file.GetInput();

				rm = new Room(file.getRoom(), file.getRecInRoom(), file.getCamInRoom());

			}
		});


		btnCaculate.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnCaculate.setBounds(22, 195, 286, 50);
		getContentPane().add(btnCaculate);
		btnCaculate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CalculateHiddenArea hidden = new CalculateHiddenArea(rm,1600000);
				double percentage = hidden.calculateHiddenVs3();
				GuiMain.mess = GuiMain.mess + "Percentage light is: "+percentage+"%\n";
				textArea.setText(GuiMain.mess);
				

			}
		});

		btnViewTheHidden.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnViewTheHidden.setBounds(22, 274, 286, 50);
		getContentPane().add(btnViewTheHidden);
		btnViewTheHidden.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				//JFrame f4 = new JFrame("CHECK A POINT");
				//f4.setVisible(true);
				//f4.setBounds(100, 100, 550, 450);
				//f4.getContentPane().setLayout(null);
				//f4.setLocationRelativeTo(null);
				CalculateHiddenArea hidden = new CalculateHiddenArea(rm,2000001);
				double percentage = hidden.calculateHiddenVs3();
				JFrame frame1 = new JFrame("Direct draw demo");
				ShowTheHidden show = new ShowTheHidden(hidden.widthRoom, hidden.longRoom, hidden);
				frame1.add(show);
			    frame1.pack();
			    frame1.setVisible(true);
			    frame1.setResizable(true);
			    frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				
			}
		});

		btnSetMinCam.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnSetMinCam.setBounds(22, 364, 286, 48);
		btnSetMinCam.setHorizontalAlignment(SwingConstants.LEFT);
		getContentPane().add(btnSetMinCam);
		btnSetMinCam.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JFrame f5 = new JFrame("CHECK A POINT");
				f5.setVisible(true);
				f5.setBounds(100, 100, 550, 450);
				f5.getContentPane().setLayout(null);
				f5.setLocationRelativeTo(null);

			}
		});

		btnPositionCam.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnPositionCam.setBounds(22, 432, 286, 39);
		getContentPane().add(btnPositionCam);
		btnPositionCam.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JFrame f6 = new JFrame("CHECK A POINT");
				f6.setVisible(true);
				f6.setBounds(100, 100, 550, 450);
				f6.getContentPane().setLayout(null);
				f6.setLocationRelativeTo(null);

			}
		});


		btnCheckPoint.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnCheckPoint.setBounds(22, 115, 286, 48);
		getContentPane().add(btnCheckPoint);
		



		JButton btnExit = new JButton("Exit");
		btnExit.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnExit.setBounds(22, 490, 286, 48);
		contentPane.add(btnExit);
		btnCheckPoint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			new CheckPoint(rm);

			}
		});

		textArea.setBounds(347, 44, 313, 443);
		contentPane.add(textArea);

	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {

				GuiMain frame = new GuiMain();
				frame.setVisible(true);
			}
		});
	}
}

