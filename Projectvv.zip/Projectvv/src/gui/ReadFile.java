package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollBar;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import space3D.*;
import java.awt.Choice;
import javax.swing.JMenu;

public class ReadFile{
	private JButton btnCheck, btnClear;
	private JTextArea textResult;
	private JLabel lblResult, lblInput;
	private JTextField textInput;
	private JScrollBar  scrollBar;


	public ReadFile(Room rm) {


		JFrame f1 = new JFrame("READ FILE");
		f1.setVisible(true);
		f1.setBounds(100, 100, 550, 450);
		f1.getContentPane().setLayout(null);
		f1.setLocationRelativeTo(null);

		btnCheck = new JButton("Check");
		btnCheck.setBounds(308, 83, 89, 23);
		f1.getContentPane().add(btnCheck);

		btnClear = new JButton("Clear");
		btnClear.setBounds(379, 368, 89, 23);
		f1.getContentPane().add(btnClear);

		textResult = new JTextArea();
		textResult.setBounds(40, 142, 449, 209);
		f1.getContentPane().add(textResult);

		lblResult = new JLabel("Result after reading");
		lblResult.setHorizontalAlignment(SwingConstants.CENTER);
		lblResult.setBounds(30, 107, 166, 23);
		f1.getContentPane().add(lblResult);

		textInput = new JTextField();
		textInput.setBounds(228, 37, 247, 32);
		f1.getContentPane().add(textInput);
		textInput.setColumns(10);

		scrollBar = new JScrollBar();
		scrollBar.setBounds(513, 142, 17, 234);
		f1.getContentPane().add(scrollBar);

		lblInput = new JLabel("Enter the path of file input");
		lblInput.setBounds(42, 46, 154, 14);
		f1.getContentPane().add(lblInput);


		btnCheck.addActionListener(new ActionListener() {

			private AbstractButton textArea;

			@Override
			public void actionPerformed(ActionEvent e) {
				//Create a file chooser
				final JFileChooser fc = new JFileChooser();
				
				//In response to a button click:
				int returnVal = fc.showOpenDialog(fc);
//				JChooser file = new JFileChooser();
//				String url = "", str;
//				url = textInput.getText();
//
//				InputFile test = new InputFile(url);
//				test.GetInput();
//				System.out.println(rm);


			}
		});
		textResult.addMouseListener(new MouseAdapter() {

			public void mouseClicked(MouseEvent e) {
				textResult.setText("");
			}
		});

	}
}
