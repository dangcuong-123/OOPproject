package gui;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class GuiCaculateTheHidden extends JFrame {
	private JTextField textField;
	public GuiCaculateTheHidden() {
		getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(143, 26, 143, 20);
		getContentPane().add(textField);
		textField.setColumns(10);
		JFrame f3 = new JFrame("Caculate The Hidden");
		f3.setVisible(true);
		f3.setBounds(100, 100, 550, 450);
		f3.getContentPane().setLayout(null);
		f3.setLocationRelativeTo(null);
		
	}
}
